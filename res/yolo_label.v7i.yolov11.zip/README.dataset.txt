# yolo_label > 2025-01-24 6:46pm
https://universe.roboflow.com/yolotest-hduxn/yolo_label-gt75e

Provided by a Roboflow user
License: undefined

